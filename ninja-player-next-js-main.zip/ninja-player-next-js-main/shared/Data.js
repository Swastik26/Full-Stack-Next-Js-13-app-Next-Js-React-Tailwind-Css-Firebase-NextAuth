const GameList=[
    {
        id:1,
        name:'Cricket',
        image:'./Images/CricketBall.png'
    },
    {
        id:2,
        name:'Tennis',
        image:'./Images/Tennis.png'
    },
    {
        id:3,
        name:'Ping Pong',
        image:'./Images/PingPong.png'
    },
    {
        id:4,
        name:'Soccer',
        image:'./Images/SoccerBall.png'
    },
    {
        id:5,
        name:'Badminton',
        image:'./Images/Badminton.png'
    },
    {
        id:6,
        name:'Trekking',
        image:'./Images/Trekking.png'
    },
    {
        id:7,
        name:'Other Games',
        image:'./Images/Puzzle.png'
    },


]

export default{
    GameList
} 